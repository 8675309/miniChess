//hw1 Jennifer Solman
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
using namespace std;


class square{
    public:
        square::square();
        square::~square();
        int x; // 0 to 5
        int y; // 0 to 4
};

class move{
    public:
            move::move(int x,int y,int z, int w);
            move::~move();
	    square toSquare;
	    square fromSquare;

};

class states{
    public:
        move* moveGen(char color);
        char board[5][6];
        char onMove;
        int count; 
}state;


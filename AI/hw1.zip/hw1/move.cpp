//Jennifer Solman hw1
#include "classes.h"

move::move(int x,int y,int z,int w){
    square toSquare.x = z; 
    square toSquare.y = w;
    square fromSquare.x = x;
    square fromSquare.y = y;
}

move::~move(){

}

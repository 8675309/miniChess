//Jennifer Solman hw1

#include "classes.h"

void createStart();
void readBoard();
void printBoard();

int main (){
    createStart();
    return 0;
}

void printBoard(){
    int i,j;
    for(i=0; i<=5; ++i){
	for(j=0; j<=4; ++j){
	    cout << state.board[i][j];
	}
	cout << "\n";
    }
}

void readBoard(){
    cin >> state.count >> state.onMove;
    char newState[36];
    cin >> newState;
    int i,j,;
    int k=0;
    for(i=0; i<=5; ++i){
	for(j=0; j<=4; ++j){
	    state.board[i][j] = newState[k];
	    ++k;
	}
	++k; //skip the newline in input
    }
}

void createStart(){
    int i;
    state.board[0][0] = 'k';     
    state.board[0][1] = 'q';     
    state.board[0][2] = 'b';     
    state.board[0][3] = 'n';     
    state.board[0][4] = 'r';     
    state.board[5][0] = 'R';     
    state.board[5][1] = 'N';     
    state.board[5][2] = 'B';     
    state.board[5][3] = 'Q';     
    state.board[5][4] = 'K';
    for (i=0; i<=4; ++i){
	    state.board[1][i] = 'p';
	    state.board[4][i] = 'P';
	    state.board[2][i] = 'x';
	    state.board[3][i] = 'x';
    }     

}



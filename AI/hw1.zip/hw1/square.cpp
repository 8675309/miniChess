//Jennifer Solman hw1

#include "classes.h"
square::square(){
    x = -1;
    y = -1;
}

square::~square(){

}


